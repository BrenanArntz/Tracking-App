// --- DEFAULT DEFAULT RESOURCES FOR NEW GROUPS ---
const DEFAULT_RESOURCES = [
  {
    id: 1,
    title: 'Standard Gospel Presentation Guide (Google Docs)',
    url: 'https://docs.google.com/document/u/0/?show_intro=true',
    desc: 'Core outline for local group evangelism training.'
  },
  {
    id: 2,
    title: 'Follow-up & Discipleship Slides (Google Slides)',
    url: 'https://slides.google.com/u/0/?show_intro=true',
    desc: 'Slide deck for training new members on follow-ups.'
  }
];

// --- INITIAL SEED DATA (LOCAL STORAGE) ---
function initSeedData() {
  if (!localStorage.getItem('evangelism_team')) {
    const defaultTeam = [
      { id: 'john_member', name: 'John Smith', email: 'john@church.com', role: 'member', groupName: 'Metro Ministry' },
      { id: 'sarah_admin', name: 'Sarah Jenkins', email: 'sarah@church.com', role: 'admin', groupName: 'Metro Ministry' },
      { id: 'mark_director', name: 'Pastor Mark', email: 'mark@church.com', role: 'director', groupName: 'Metro Ministry' },
      { id: 'super_admin', name: 'System Admin', email: 'admin@system.com', role: 'super_admin', groupName: 'System' }
    ];
    localStorage.setItem('evangelism_team', JSON.stringify(defaultTeam));
  }

  if (!localStorage.getItem('evangelism_logs')) {
    const defaultLogs = [
      {
        id: 101,
        authorId: 'john_member',
        authorName: 'John Smith',
        groupName: 'Metro Ministry',
        name: 'David at the Park',
        date: new Date().toISOString().split('T')[0],
        evangelists: ['John Smith', 'Sarah Jenkins'],
        notes: 'Shared testimony and prayed for his family.'
      }
    ];
    localStorage.setItem('evangelism_logs', JSON.stringify(defaultLogs));
  }

  if (!localStorage.getItem('evangelism_events')) {
    const defaultEvents = [
      {
        id: 201,
        groupName: 'Metro Ministry',
        title: 'Saturday Park Outreach',
        datetime: new Date(Date.now() + 86400000 * 2).toISOString().slice(0, 16), // 2 days in future
        status: 'Confirmed',
        location: 'Central Park Pavilion',
        description: 'Meeting by the main entrance. Handing out tracts and praying with people.',
        rsvps: { 'john_member': 'going', 'sarah_admin': 'going' }
      }
    ];
    localStorage.setItem('evangelism_events', JSON.stringify(defaultEvents));
  }

  if (!localStorage.getItem('evangelism_resources')) {
    const defaultRes = [
      { id: 301, groupName: 'Metro Ministry', title: DEFAULT_RESOURCES[0].title, url: DEFAULT_RESOURCES[0].url, desc: DEFAULT_RESOURCES[0].desc },
      { id: 302, groupName: 'Metro Ministry', title: DEFAULT_RESOURCES[1].title, url: DEFAULT_RESOURCES[1].url, desc: DEFAULT_RESOURCES[1].desc }
    ];
    localStorage.setItem('evangelism_resources', JSON.stringify(defaultRes));
  }
}

async function ensureSupabaseSeedData() {
  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;
  if (!supabase) return { ok: false, message: 'Supabase not configured.' };

  try {
    const { data: groups, error: groupsError } = await supabase.from('groups').select('*');
    if (groupsError) {
      return { ok: false, message: groupsError.message };
    }

    let metroGroup = (groups || []).find(group => group.name === 'Metro Ministry');

    if (!metroGroup) {
      const { data: insertedGroup, error: insertGroupError } = await supabase
        .from('groups')
        .insert([{ id: 'metro_ministry', name: 'Metro Ministry' }])
        .select();

      if (insertGroupError) {
        return { ok: false, message: insertGroupError.message };
      }

      metroGroup = insertedGroup && insertedGroup[0];
    }

    const { data: users, error: usersError } = await supabase.from('users').select('*');
    if (usersError) {
      return { ok: false, message: usersError.message };
    }

    const defaultUsers = [
      { id: 'john_member', full_name: 'John Smith', email: 'john@church.com', role: 'member', group_id: metroGroup.id || 'metro_ministry' },
      { id: 'sarah_admin', full_name: 'Sarah Jenkins', email: 'sarah@church.com', role: 'admin', group_id: metroGroup.id || 'metro_ministry' },
      { id: 'mark_director', full_name: 'Pastor Mark', email: 'mark@church.com', role: 'director', group_id: metroGroup.id || 'metro_ministry' },
      { id: 'super_admin', full_name: 'System Admin', email: 'admin@system.com', role: 'super_admin', group_id: null }
    ];

    if (!users || users.length === 0) {
      const { error: insertUsersError } = await supabase.from('users').insert(defaultUsers);
      if (insertUsersError) {
        return { ok: false, message: insertUsersError.message };
      }
    }

    const { data: syncedUsers } = await supabase.from('users').select('id, full_name, email, role, group_id, groups(name)');
    if (syncedUsers) {
      const mapped = syncedUsers.map(user => ({
        id: user.id,
        name: user.full_name,
        email: user.email,
        role: user.role,
        groupName: user.groups && user.groups.name ? user.groups.name : 'System'
      }));

      localStorage.setItem('evangelism_team', JSON.stringify(mapped));
    }

    return { ok: true, message: 'Supabase seed data synced.' };
  } catch (error) {
    console.warn('Supabase seed sync failed:', error);
    return { ok: false, message: error.message || 'Unknown error.' };
  }
}

window.ensureSupabaseSeedData = ensureSupabaseSeedData;

initSeedData();

if (window.testSupabaseConnection) {
  setTimeout(() => {
    window.testSupabaseConnection().then((result) => {
      console.log('Supabase status:', result.message || 'Unknown');
      if (result.ok) {
        ensureSupabaseSeedData().then((syncResult) => {
          console.log('Supabase seed sync:', syncResult.message || 'Unknown');
        });
      }
    }).catch((error) => {
      console.warn('Supabase status check failed:', error);
    });
  }, 100);
}

// --- STATE MANAGEMENT ---
let currentUser = null;
let activeGroupName = null;

function getStoredArray(key) {
  try {
    const value = localStorage.getItem(key);
    const parsed = value ? JSON.parse(value) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.warn(`Unable to parse ${key} from localStorage. Resetting to empty array.`);
    return [];
  }
}

async function loadTeamDataFromSupabase() {
  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;
  if (!supabase) return getStoredArray('evangelism_team');

  try {
    const { data, error } = await supabase
      .from('users')
      .select('id, full_name, email, role, group_id, groups!group_id(name)');

    if (error || !data) {
      console.warn('Supabase user query failed:', error ? error.message : 'No data returned.');
      return getStoredArray('evangelism_team');
    }

    const mapped = data.map(user => ({
      id: user.id,
      name: user.full_name,
      email: user.email,
      role: user.role,
      groupName: user.groups && user.groups.name ? user.groups.name : 'System'
    }));

    localStorage.setItem('evangelism_team', JSON.stringify(mapped));
    return mapped;
  } catch (error) {
    console.warn('Unable to load team data from Supabase, using localStorage fallback.', error);
    return getStoredArray('evangelism_team');
  }
}

async function loadChatLogsFromSupabase() {
  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;
  if (!supabase) return getStoredArray('evangelism_logs');

  try {
    const groupId = getEffectiveGroupId();
    const { data, error } = await supabase
      .from('chat_logs')
      .select('*, groups!group_id(name)')
      .eq('group_id', groupId);

    if (error || !data) {
      console.warn('Supabase chat log query failed:', error ? error.message : 'No data returned.');
      return getStoredArray('evangelism_logs');
    }

    const mapped = data.map(log => ({
      id: log.id,
      authorId: log.author_id,
      authorName: log.author_name || '',
      groupName: log.groups && log.groups.name ? log.groups.name : getEffectiveGroupName(),
      name: log.person_name,
      date: log.log_date,
      evangelists: log.evangelists || [],
      progress: log.progress || 0,
      heardGospelCount: log.heard_gospel_count || 0,
      professedCount: log.professed_count || 0,
      notes: log.notes || '',
      photo: log.photo_url || ''
    }));

    localStorage.setItem('evangelism_logs', JSON.stringify(mapped));
    return mapped;
  } catch (error) {
    console.warn('Unable to load chat logs from Supabase, using localStorage fallback.', error);
    return getStoredArray('evangelism_logs');
  }
}

async function loadEventsFromSupabase() {
  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;
  if (!supabase) return getStoredArray('evangelism_events');

  try {
    const groupId = getEffectiveGroupId();
    const { data, error } = await supabase
      .from('events')
      .select('*, groups!group_id(name)')
      .eq('group_id', groupId);

    if (error || !data) {
      console.warn('Supabase events query failed:', error ? error.message : 'No data returned.');
      return getStoredArray('evangelism_events');
    }

    const mapped = data.map(event => ({
      id: event.id,
      groupName: event.groups && event.groups.name ? event.groups.name : getEffectiveGroupName(),
      title: event.title,
      datetime: event.event_datetime,
      status: event.status || 'Confirmed',
      location: event.location,
      description: event.description || '',
      rsvps: event.rsvps || {}
    }));

    localStorage.setItem('evangelism_events', JSON.stringify(mapped));
    return mapped;
  } catch (error) {
    console.warn('Unable to load events from Supabase, using localStorage fallback.', error);
    return getStoredArray('evangelism_events');
  }
}

async function loadResourcesFromSupabase() {
  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;
  if (!supabase) return getStoredArray('evangelism_resources');

  try {
    const groupId = getEffectiveGroupId();
    const { data, error } = await supabase
      .from('resources')
      .select('*, groups!group_id(name)')
      .eq('group_id', groupId);

    if (error || !data) {
      console.warn('Supabase resources query failed:', error ? error.message : 'No data returned.');
      return getStoredArray('evangelism_resources');
    }

    const mapped = data.map(resource => ({
      id: resource.id,
      groupName: resource.groups && resource.groups.name ? resource.groups.name : getEffectiveGroupName(),
      title: resource.title,
      url: resource.url,
      desc: resource.description || ''
    }));

    localStorage.setItem('evangelism_resources', JSON.stringify(mapped));
    return mapped;
  } catch (error) {
    console.warn('Unable to load resources from Supabase, using localStorage fallback.', error);
    return getStoredArray('evangelism_resources');
  }
}

function slugifyGroupName(value) {
  if (!value) return 'metro_ministry';
  return String(value)
    .trim()
    .toLowerCase()
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '') || 'metro_ministry';
}

function getEffectiveGroupId() {
  const targetGroupName = getEffectiveGroupName();
  if (!targetGroupName) return 'metro_ministry';

  const cachedGroupIds = JSON.parse(localStorage.getItem('evangelism_group_ids') || '{}');
  if (cachedGroupIds[targetGroupName]) {
    return cachedGroupIds[targetGroupName];
  }

  const builtInGroupIdMap = {
    'Metro Ministry': 'metro_ministry',
    'System': 'system'
  };

  return builtInGroupIdMap[targetGroupName] || slugifyGroupName(targetGroupName);
}

function escapeHtml(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function ensureUserSession() {
  if (!currentUser) {
    dashboardScreen.classList.remove('active');
    authScreen.classList.add('active');
    return false;
  }
  return true;
}

document.getElementById('chat-progress').addEventListener('change', () => syncLogCounters(false));
document.getElementById('edit-chat-progress').addEventListener('change', () => syncLogCounters(true));

function handlePhotoDelete(isEdit = false) {
  const photoInput = document.getElementById(isEdit ? 'edit-chat-photo' : 'chat-photo');
  const clearButton = document.getElementById(isEdit ? 'clear-edit-chat-photo' : 'clear-chat-photo');
  const deleteFlag = document.getElementById(isEdit ? 'edit-chat-photo-delete' : 'chat-photo-delete');
  const previewWrap = document.getElementById('edit-photo-preview-wrap');
  const previewImage = document.getElementById('edit-photo-preview');

  if (!photoInput || !clearButton || !deleteFlag) return;

  photoInput.value = '';
  deleteFlag.value = 'true';
  clearButton.style.display = 'none';

  if (previewWrap && previewImage) {
    previewWrap.style.display = 'none';
    previewImage.src = '';
  }

  if (isEdit) {
    const logId = parseInt(document.getElementById('edit-log-id').value || '0', 10);
    if (logId) {
      const logs = getStoredArray('evangelism_logs');
      const index = logs.findIndex(log => log.id === logId);
      if (index !== -1) {
        logs[index].photo = '';
        localStorage.setItem('evangelism_logs', JSON.stringify(logs));
      }
    }
  }
}

function bindPhotoControls() {
  const photoInput = document.getElementById('chat-photo');
  const clearButton = document.getElementById('clear-chat-photo');
  if (photoInput && clearButton) {
    photoInput.addEventListener('change', () => {
      const deleteFlag = document.getElementById('chat-photo-delete');
      if (deleteFlag) deleteFlag.value = 'false';
      clearButton.style.display = photoInput.files && photoInput.files[0] ? 'inline-flex' : 'none';
    });
    clearButton.addEventListener('click', () => handlePhotoDelete(false));
  }

  const editPhotoInput = document.getElementById('edit-chat-photo');
  const editClearButton = document.getElementById('clear-edit-chat-photo');
  if (editPhotoInput && editClearButton) {
    editPhotoInput.addEventListener('change', () => {
      const deleteFlag = document.getElementById('edit-chat-photo-delete');
      if (deleteFlag) deleteFlag.value = 'false';
      editClearButton.style.display = editPhotoInput.files && editPhotoInput.files[0] ? 'inline-flex' : 'none';
    });
    editClearButton.addEventListener('click', () => handlePhotoDelete(true));
  }
}

bindPhotoControls();

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('Unable to read file'));
    reader.readAsDataURL(file);
  });
}

function getProgressLabel(level) {
  const labels = {
    0: '0 - No Progress',
    1: '1 - God\'s Existence',
    2: '2 - Law',
    3: '3 - False Ways',
    4: '4 - Gospel',
    5: '5 - Checking Questions',
    6: '6 - Complete (Not Professing)',
    7: '7 - Complete (Not Professing)',
    8: '8 - Already a Believer'
  };

  return labels[String(level)] || '0 - No Progress';
}

function syncLogCounters(isEdit = false) {
  const progressSelect = document.getElementById(isEdit ? 'edit-chat-progress' : 'chat-progress');
  const heardRow = document.getElementById(isEdit ? 'edit-heard-gospel-row' : 'heard-gospel-row');
  const professedRow = document.getElementById(isEdit ? 'edit-professed-row' : 'professed-row');
  const heardInput = document.getElementById(isEdit ? 'edit-heard-gospel-count' : 'heard-gospel-count');
  const professedInput = document.getElementById(isEdit ? 'edit-professed-count' : 'professed-count');

  if (!progressSelect || !heardRow || !professedRow || !heardInput || !professedInput) return;

  const progressValue = Number(progressSelect.value || 0);
  const showHeard = progressValue >= 4 && progressValue <= 7;
  const showProfessed = progressValue === 7;

  heardRow.style.display = showHeard ? 'block' : 'none';
  professedRow.style.display = showProfessed ? 'block' : 'none';

  if (showHeard && Number(heardInput.value || 0) < 1) {
    heardInput.value = 1;
  }

  if (showProfessed && Number(professedInput.value || 0) < 1) {
    professedInput.value = 1;
  }
}

function getEffectiveGroupName() {
  if (!currentUser) return null;

  if (currentUser.role === 'super_admin') {
    return activeGroupName || currentUser.groupName || 'System';
  }

  return currentUser.groupName || '';
}

async function setActiveGroupContext(groupName) {
  if (!groupName || !currentUser || currentUser.role !== 'super_admin') return;
  activeGroupName = groupName;
  groupBadge.textContent = `${groupName} (Admin View)`;
  switchTab('tab-tracker');
  renderEvangelistCheckboxes();
  await renderLogs();
  await renderCalendar();
  await renderResources();
  await renderTeam();
  renderSuperAdminPanel();
}

// --- DOM ELEMENTS ---
const authScreen = document.getElementById('auth-screen');
const dashboardScreen = document.getElementById('dashboard-screen');
const loginForm = document.getElementById('login-form');
const logoutBtn = document.getElementById('logout-btn');
const userDisplayName = document.getElementById('user-display-name');
const roleBadge = document.getElementById('role-badge');
const groupBadge = document.getElementById('group-badge');

const navTeamTab = document.getElementById('nav-team-tab');
const navAdminTab = document.getElementById('nav-admin-tab');
const tabBtns = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

// --- AUTHENTICATION & LOGIN ---
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const testRoleSelect = document.getElementById('test-role').value;

  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;

  // If test mode is being used (test-role has a value), use that instead
  if (testRoleSelect) {
    let team = getStoredArray('evangelism_team');
    if (supabase) {
      team = await loadTeamDataFromSupabase();
    }

    currentUser = team.find(u => u.id === testRoleSelect) || null;

    if (!currentUser) {
      alert('Selected user was not found. Please try again.');
      return;
    }

    if (currentUser.role === 'super_admin') {
      const directorGroups = team.filter(u => u.role === 'director' && u.groupName).map(u => u.groupName);
      activeGroupName = directorGroups[0] || currentUser.groupName || 'System';
    } else {
      activeGroupName = currentUser.groupName || null;
    }

    showDashboard();
    return;
  }

  // Use Supabase auth with email/password
  if (!email || !password) {
    alert('Please enter your email and password.');
    return;
  }

  if (!supabase) {
    alert('Authentication service is not available. Please use test mode.');
    return;
  }

  try {
    // Sign in with Supabase Auth
    const authResult = await window.signInUser(email, password);
    if (!authResult.ok) {
      alert('Login failed: ' + authResult.message);
      return;
    }

    const authUser = authResult.data.user;

    // Look up the user in the users table
    const { data: users, error } = await supabase
      .from('users')
      .select('id, full_name, email, role, group_id, groups!group_id(name)')
      .eq('auth_user_id', authUser.id);

    if (error || !users || users.length === 0) {
      alert('User profile not found. Please contact an administrator.');
      return;
    }

    const userRecord = users[0];
    currentUser = {
      id: userRecord.id,
      name: userRecord.full_name,
      email: userRecord.email,
      role: userRecord.role,
      groupName: userRecord.groups ? userRecord.groups.name : null
    };

    if (currentUser.role === 'super_admin') {
      // Load all director groups for super admin
      const { data: directorUsers } = await supabase
        .from('users')
        .select('group_id, groups!group_id(name)')
        .eq('role', 'director');

      const directorGroups = directorUsers
        .map(u => u.groups ? u.groups.name : null)
        .filter(Boolean);
      activeGroupName = directorGroups[0] || currentUser.groupName || 'System';
    } else {
      activeGroupName = currentUser.groupName || null;
    }

    showDashboard();
  } catch (err) {
    alert('An error occurred during login: ' + err.message);
  }
});

logoutBtn.addEventListener('click', async () => {
  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;
  if (supabase) {
    await window.signOutUser();
  }
  currentUser = null;
  dashboardScreen.classList.remove('active');
  authScreen.classList.add('active');
});

async function showDashboard() {
  if (!currentUser) {
    return;
  }

  authScreen.classList.remove('active');
  dashboardScreen.classList.add('active');

  const effectiveGroup = getEffectiveGroupName();

  userDisplayName.textContent = currentUser.name;
  roleBadge.textContent = currentUser.role.replace('_', ' ');
  groupBadge.textContent = currentUser.role === 'super_admin'
    ? `${effectiveGroup || 'System'} (Admin View)`
    : (effectiveGroup || 'Global');

  const isSuper = currentUser.role === 'super_admin';
  const isDirector = currentUser.role === 'director';
  const isAdmin = currentUser.role === 'admin';
  const isLeader = isSuper || isDirector || isAdmin;

  // Nav Visibility
  navTeamTab.style.display = (isSuper || isDirector) ? 'inline-block' : 'none';
  navAdminTab.style.display = isSuper ? 'inline-block' : 'none';

  // Form Visibilities
  document.getElementById('add-event-card').style.display = isLeader ? 'block' : 'none';
  document.getElementById('add-resource-card').style.display = isLeader ? 'block' : 'none';

  // Default dates
  document.getElementById('chat-date').valueAsDate = new Date();
  document.getElementById('heard-gospel-count').value = 1;
  document.getElementById('professed-count').value = 1;
  syncLogCounters(false);

  switchTab('tab-tracker');
  renderEvangelistCheckboxes();
  await renderLogs();
  await renderCalendar();
  await renderResources();
  await renderTeam();
  if (isSuper) await renderSuperAdminPanel();
}

// --- TAB SWITCHING ---
tabBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    switchTab(btn.getAttribute('data-tab'));
  });
});

function switchTab(tabId) {
  tabBtns.forEach(b => b.classList.remove('active'));
  tabContents.forEach(c => c.classList.remove('active'));

  const activeBtn = document.querySelector(`[data-tab="${tabId}"]`);
  const activeContent = document.getElementById(tabId);

  if (activeBtn) activeBtn.classList.add('active');
  if (activeContent) activeContent.classList.add('active');
}

// --- EVANGELIST CHECKBOXES ---
function renderEvangelistCheckboxes(container = document.getElementById('evangelists-checkbox-group'), selected = []) {
  if (!ensureUserSession()) return;

  const team = getStoredArray('evangelism_team');
  const targetGroup = getEffectiveGroupName();
  const localMembers = team.filter(m => currentUser.role === 'super_admin'
    ? m.groupName === targetGroup
    : m.groupName === currentUser.groupName);

  container.innerHTML = '';
  localMembers.forEach(member => {
    const isCurrentUser = member.id === currentUser.id;
    const isChecked = selected.length > 0 ? selected.includes(member.name) : isCurrentUser;

    const label = document.createElement('label');
    label.className = `checkbox-chip ${isCurrentUser ? 'highlighted' : ''}`;
    label.innerHTML = `
      <input type="checkbox" value="${escapeHtml(member.name)}" ${isChecked ? 'checked' : ''}>
      ${escapeHtml(member.name)} ${isCurrentUser ? '(You)' : ''}
    `;
    container.appendChild(label);
  });
}

// --- LOG CREATION & RENDER ---
document.getElementById('tracker-form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const selectedEvangelists = Array.from(
    document.getElementById('evangelists-checkbox-group').querySelectorAll('input[type="checkbox"]:checked')
  ).map(cb => cb.value);

  const photoInput = document.getElementById('chat-photo');
  let photoData = '';

  if (photoInput && photoInput.files && photoInput.files[0]) {
    photoData = await fileToDataUrl(photoInput.files[0]);
  }

  if (document.getElementById('chat-photo-delete').value === 'true') {
    photoData = '';
  }

  const targetGroup = getEffectiveGroupName();
  const heardGospelCount = Number(document.getElementById('heard-gospel-count').value || 1);
  const professedCount = Number(document.getElementById('professed-count').value || 1);
  const progress = Number(document.getElementById('chat-progress').value);

  const newLog = {
    id: String(Date.now()),
    authorId: currentUser.id,
    authorName: currentUser.name,
    groupName: targetGroup,
    name: document.getElementById('person-name').value,
    date: document.getElementById('chat-date').value,
    evangelists: selectedEvangelists,
    progress: progress,
    heardGospelCount: progress >= 4 && progress <= 7 ? heardGospelCount : 0,
    professedCount: progress === 7 ? professedCount : 0,
    photo: photoData,
    notes: document.getElementById('chat-notes').value
  };

  // Try to save to Supabase first
  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;
  if (supabase) {
    try {
      const groupId = getEffectiveGroupId();
      const { error: insertError } = await supabase
        .from('chat_logs')
        .insert([{
          id: newLog.id,
          group_id: groupId,
          author_id: newLog.authorId,
          person_name: newLog.name,
          log_date: newLog.date,
          evangelists: newLog.evangelists,
          progress: newLog.progress,
          heard_gospel_count: newLog.heardGospelCount,
          professed_count: newLog.professedCount,
          notes: newLog.notes,
          photo_url: newLog.photo
        }]);

      if (insertError) {
        console.warn('Supabase insert failed:', insertError.message);
      } else {
        console.log('Chat log saved to Supabase:', newLog.id);
      }
    } catch (err) {
      console.warn('Supabase error:', err.message);
    }
  }

  // Always save to localStorage as backup
  const logs = JSON.parse(localStorage.getItem('evangelism_logs') || '[]');
  logs.unshift(newLog);
  localStorage.setItem('evangelism_logs', JSON.stringify(logs));

  document.getElementById('tracker-form').reset();
  document.getElementById('chat-date').valueAsDate = new Date();
  document.getElementById('heard-gospel-count').value = 1;
  document.getElementById('professed-count').value = 1;
  document.getElementById('chat-photo-delete').value = 'false';
  document.getElementById('clear-chat-photo').style.display = 'none';
  syncLogCounters(false);
  renderEvangelistCheckboxes();
  await renderLogs();
});

async function renderLogs() {
  if (!ensureUserSession()) return;

  const logs = await loadChatLogsFromSupabase();
  const logList = document.getElementById('log-list');
  logList.innerHTML = '';

  const targetGroup = getEffectiveGroupName();
  const relevantLogs = logs.filter(l => currentUser.role === 'super_admin'
    ? l.groupName === targetGroup
    : l.groupName === currentUser.groupName);

  if (relevantLogs.length === 0) {
    logList.innerHTML = '<li class="empty-state">No conversations logged yet.</li>';
    return;
  }

  relevantLogs.forEach(log => {
    const isAuthorized = ['super_admin', 'director', 'admin'].includes(currentUser.role) || log.authorId === currentUser.id;

    const li = document.createElement('li');
    li.className = 'log-item';

    const tagsHtml = (log.evangelists || []).map(name => `
      <span class="tag ${name === log.authorName ? 'logged-by' : ''}">${name}</span>
    `).join('');

    const photoHtml = log.photo
      ? `<img src="${log.photo}" alt="Conversation photo" class="log-photo" />`
      : '';

    const heardGospelCount = Number(log.heardGospelCount || 0);
    const professedCount = Number(log.professedCount || 0);
    const counterHtml = (Number(log.progress || 0) >= 4 && Number(log.progress || 0) <= 7)
      ? `<div class="log-counter-row">Heard the Gospel: ${escapeHtml(String(heardGospelCount))}</div>`
      : '';
    const professedHtml = Number(log.progress || 0) === 7
      ? `<div class="log-counter-row">Professed: ${escapeHtml(String(professedCount))}</div>`
      : '';

    const progressHtml = `
      <div class="log-progress">
        <span class="progress-label">Progress:</span>
        <span class="progress-value">${escapeHtml(getProgressLabel(log.progress))}</span>
      </div>
    `;

    li.innerHTML = `
      <div class="log-item-header">
        <span class="log-item-title">${escapeHtml(log.name)}</span>
        <span class="log-item-date">${escapeHtml(log.date)}</span>
      </div>
      <div class="evangelist-tags">${tagsHtml}</div>
      ${progressHtml}
      ${counterHtml}
      ${professedHtml}
      ${photoHtml}
      <p class="log-item-notes">${escapeHtml(log.notes || 'No notes added.')}</p>

      ${isAuthorized ? `
        <div class="log-actions">
          <button class="btn-action edit" onclick="openEditModal(${log.id})">Edit</button>
          <button class="btn-action delete" onclick="deleteLog(${log.id})">Delete</button>
        </div>
      ` : ''}
    `;
    logList.appendChild(li);
  });
}

// Log Edit/Delete Modals
window.openEditModal = function(logId) {
  const logs = JSON.parse(localStorage.getItem('evangelism_logs') || '[]');
  const log = logs.find(l => l.id === logId);
  if (!log) return;

  const previewWrap = document.getElementById('edit-photo-preview-wrap');
  const previewImage = document.getElementById('edit-photo-preview');
  const photoInput = document.getElementById('edit-chat-photo');
  const clearButton = document.getElementById('clear-edit-chat-photo');
  const deleteFlag = document.getElementById('edit-chat-photo-delete');

  document.getElementById('edit-log-id').value = log.id;
  document.getElementById('edit-person-name').value = log.name;
  document.getElementById('edit-chat-date').value = log.date;
  document.getElementById('edit-chat-progress').value = String(log.progress || 0);
  document.getElementById('edit-heard-gospel-count').value = Number(log.heardGospelCount || 1);
  document.getElementById('edit-professed-count').value = Number(log.professedCount || 1);
  document.getElementById('edit-chat-notes').value = log.notes;
  if (photoInput) photoInput.value = '';
  if (deleteFlag) deleteFlag.value = 'false';

  if (previewWrap && previewImage) {
    if (log.photo) {
      previewImage.src = log.photo;
      previewWrap.style.display = 'block';
      if (clearButton) clearButton.style.display = 'inline-flex';
    } else {
      previewImage.src = '';
      previewWrap.style.display = 'none';
      if (clearButton) clearButton.style.display = 'none';
    }
  }

  if (deleteFlag) deleteFlag.value = 'false';

  renderEvangelistCheckboxes(document.getElementById('edit-evangelists-checkbox-group'), log.evangelists || []);
  syncLogCounters(true);
  document.getElementById('edit-modal').classList.add('active');
};

document.getElementById('close-modal-btn').addEventListener('click', () => {
  document.getElementById('edit-modal').classList.remove('active');
});

document.getElementById('edit-tracker-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const logId = parseInt(document.getElementById('edit-log-id').value);
  const logs = JSON.parse(localStorage.getItem('evangelism_logs') || '[]');
  const index = logs.findIndex(l => l.id === logId);

  if (index !== -1) {
    const checkboxes = document.getElementById('edit-evangelists-checkbox-group').querySelectorAll('input[type="checkbox"]:checked');
    const photoInput = document.getElementById('edit-chat-photo');
    const progressValue = Number(document.getElementById('edit-chat-progress').value || 0);

    logs[index].name = document.getElementById('edit-person-name').value;
    logs[index].date = document.getElementById('edit-chat-date').value;
    logs[index].notes = document.getElementById('edit-chat-notes').value;
    logs[index].evangelists = Array.from(checkboxes).map(cb => cb.value);
    logs[index].progress = String(progressValue);
    logs[index].heardGospelCount = progressValue >= 4 && progressValue <= 7 ? Number(document.getElementById('edit-heard-gospel-count').value || 1) : 0;
    logs[index].professedCount = progressValue === 7 ? Number(document.getElementById('edit-professed-count').value || 1) : 0;

    if (document.getElementById('edit-chat-photo-delete').value === 'true') {
      logs[index].photo = '';
    } else if (photoInput && photoInput.files && photoInput.files[0]) {
      logs[index].photo = await fileToDataUrl(photoInput.files[0]);
    }

    localStorage.setItem('evangelism_logs', JSON.stringify(logs));
    document.getElementById('edit-modal').classList.remove('active');
    renderLogs();
  }
});

window.deleteLog = function(logId) {
  if (confirm('Delete this chat entry?')) {
    let logs = JSON.parse(localStorage.getItem('evangelism_logs') || '[]');
    logs = logs.filter(l => l.id !== logId);
    localStorage.setItem('evangelism_logs', JSON.stringify(logs));
    renderLogs();
  }
};

// --- CALENDAR MANAGEMENT ---
document.getElementById('event-form').addEventListener('submit', (e) => {
  e.preventDefault();

  const targetGroup = getEffectiveGroupName();

  const newEvent = {
    id: Date.now(),
    groupName: targetGroup,
    title: document.getElementById('event-title').value,
    datetime: document.getElementById('event-date').value,
    status: document.getElementById('event-status').value,
    location: document.getElementById('event-location').value,
    description: document.getElementById('event-description').value,
    rsvps: {}
  };

  const events = JSON.parse(localStorage.getItem('evangelism_events') || '[]');
  events.push(newEvent);
  localStorage.setItem('evangelism_events', JSON.stringify(events));

  document.getElementById('event-form').reset();
  renderCalendar();
});

async function renderCalendar() {
  if (!ensureUserSession()) return;

  const events = await loadEventsFromSupabase();
  const team = getStoredArray('evangelism_team');
  const list = document.getElementById('calendar-event-list');
  list.innerHTML = '';

  const now = new Date();

  const targetGroup = getEffectiveGroupName();

  // Filter out passed events AND separate by local group
  const upcomingEvents = events.filter(evt => {
    const isFuture = new Date(evt.datetime) >= now;
    const isSameGroup = currentUser.role === 'super_admin'
      ? evt.groupName === targetGroup
      : evt.groupName === currentUser.groupName;
    return isFuture && isSameGroup;
  });

  // Sort by date ascending
  upcomingEvents.sort((a, b) => new Date(a.datetime) - new Date(b.datetime));

  if (upcomingEvents.length === 0) {
    list.innerHTML = '<p class="empty-state">No upcoming events scheduled for your group.</p>';
    return;
  }

  const isLeader = ['super_admin', 'director', 'admin'].includes(currentUser.role);

  upcomingEvents.forEach(evt => {
    const formattedDate = new Date(evt.datetime).toLocaleString([], {
      weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });

    const currentRsvp = (evt.rsvps && evt.rsvps[currentUser.id]) || '';

    // Calculate attendee lists
    const goingNames = [];
    const maybeNames = [];
    if (evt.rsvps) {
      Object.entries(evt.rsvps).forEach(([uId, response]) => {
        const u = team.find(t => t.id === uId);
        if (u) {
          if (response === 'going') goingNames.push(u.name);
          if (response === 'maybe') maybeNames.push(u.name);
        }
      });
    }

    const card = document.createElement('div');
    card.className = 'event-card';
    card.innerHTML = `
      <div class="event-header">
        <span class="event-title">${escapeHtml(evt.title)}</span>
        <span class="status-badge ${evt.status.toLowerCase()}">${escapeHtml(evt.status)}</span>
      </div>
      <div class="event-meta">
        <span>📅 ${escapeHtml(formattedDate)}</span>
        <span>📍 ${escapeHtml(evt.location)}</span>
      </div>
      <p class="event-desc">${escapeHtml(evt.description || 'No description provided.')}</p>
      
      <!-- RSVP CONTROLS -->
      <div class="rsvp-section">
        <div class="rsvp-title">Your RSVP:</div>
        <div class="rsvp-buttons">
          <button class="rsvp-btn ${currentRsvp === 'going' ? 'active-going' : ''}" onclick="setRSVP(${evt.id}, 'going')">Going</button>
          <button class="rsvp-btn ${currentRsvp === 'maybe' ? 'active-maybe' : ''}" onclick="setRSVP(${evt.id}, 'maybe')">Maybe</button>
          <button class="rsvp-btn ${currentRsvp === 'not_going' ? 'active-not_going' : ''}" onclick="setRSVP(${evt.id}, 'not_going')">Not Going</button>
        </div>
        <div class="rsvp-attendees">
          <strong>Going (${goingNames.length}):</strong> ${goingNames.join(', ') || 'None yet'}<br>
          <strong>Maybe (${maybeNames.length}):</strong> ${maybeNames.join(', ') || 'None yet'}
        </div>
      </div>

      ${isLeader ? `
        <div class="log-actions" style="margin-top:12px;">
          <button class="btn-action edit" onclick="openEditEventModal(${evt.id})">Edit Event</button>
          <button class="btn-action delete" onclick="deleteEvent(${evt.id})">Delete Event</button>
        </div>
      ` : ''}
    `;
    list.appendChild(card);
  });
}

window.setRSVP = function(eventId, status) {
  const events = JSON.parse(localStorage.getItem('evangelism_events') || '[]');
  const evt = events.find(e => e.id === eventId);
  if (evt) {
    if (!evt.rsvps) evt.rsvps = {};
    evt.rsvps[currentUser.id] = status;
    localStorage.setItem('evangelism_events', JSON.stringify(events));
    renderCalendar();
  }
};

window.openEditEventModal = function(eventId) {
  const events = JSON.parse(localStorage.getItem('evangelism_events') || '[]');
  const evt = events.find(e => e.id === eventId);
  if (!evt) return;

  document.getElementById('edit-event-id').value = evt.id;
  document.getElementById('edit-event-title').value = evt.title;
  document.getElementById('edit-event-date').value = evt.datetime;
  document.getElementById('edit-event-status').value = evt.status;
  document.getElementById('edit-event-location').value = evt.location;
  document.getElementById('edit-event-description').value = evt.description;

  document.getElementById('edit-event-modal').classList.add('active');
};

document.getElementById('close-event-modal-btn').addEventListener('click', () => {
  document.getElementById('edit-event-modal').classList.remove('active');
});

document.getElementById('edit-event-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const id = parseInt(document.getElementById('edit-event-id').value);
  const events = JSON.parse(localStorage.getItem('evangelism_events') || '[]');
  const index = events.findIndex(e => e.id === id);

  if (index !== -1) {
    events[index].title = document.getElementById('edit-event-title').value;
    events[index].datetime = document.getElementById('edit-event-date').value;
    events[index].status = document.getElementById('edit-event-status').value;
    events[index].location = document.getElementById('edit-event-location').value;
    events[index].description = document.getElementById('edit-event-description').value;

    localStorage.setItem('evangelism_events', JSON.stringify(events));
    document.getElementById('edit-event-modal').classList.remove('active');
    renderCalendar();
  }
});

window.deleteEvent = function(eventId) {
  if (confirm('Delete this event outing?')) {
    let events = JSON.parse(localStorage.getItem('evangelism_events') || '[]');
    events = events.filter(e => e.id !== eventId);
    localStorage.setItem('evangelism_events', JSON.stringify(events));
    renderCalendar();
  }
};

// --- RESOURCES MANAGEMENT ---
document.getElementById('resource-form').addEventListener('submit', (e) => {
  e.preventDefault();

  const targetGroup = getEffectiveGroupName();

  const newResource = {
    id: Date.now(),
    groupName: targetGroup,
    title: document.getElementById('resource-title').value,
    url: document.getElementById('resource-url').value,
    desc: document.getElementById('resource-desc').value
  };

  const resources = JSON.parse(localStorage.getItem('evangelism_resources') || '[]');
  resources.push(newResource);
  localStorage.setItem('evangelism_resources', JSON.stringify(resources));

  document.getElementById('resource-form').reset();
  renderResources();
});

async function renderResources() {
  if (!ensureUserSession()) return;

  const resources = await loadResourcesFromSupabase();
  const list = document.getElementById('resource-list');
  list.innerHTML = '';

  const targetGroup = getEffectiveGroupName();
  const localResources = resources.filter(r => currentUser.role === 'super_admin'
    ? r.groupName === targetGroup
    : r.groupName === currentUser.groupName);

  if (localResources.length === 0) {
    list.innerHTML = '<li class="empty-state">No resources added for this group.</li>';
    return;
  }

  const isLeader = ['super_admin', 'director', 'admin'].includes(currentUser.role);

  localResources.forEach(res => {
    const li = document.createElement('li');
    li.className = 'resource-item';
    li.innerHTML = `
      <div class="resource-info">
        <h4><a href="${escapeHtml(res.url)}" target="_blank" rel="noopener">📄 ${escapeHtml(res.title)}</a></h4>
        <p class="resource-desc">${escapeHtml(res.desc || 'Google Doc / Slide link')}</p>
      </div>
      ${isLeader ? `
        <div class="log-actions" style="border:none; padding:0; margin:0;">
          <button class="btn-action edit" onclick="openEditResourceModal(${res.id})">Edit</button>
          <button class="btn-action delete" onclick="deleteResource(${res.id})">Delete</button>
        </div>
      ` : ''}
    `;
    list.appendChild(li);
  });
}

window.openEditResourceModal = function(id) {
  const resources = JSON.parse(localStorage.getItem('evangelism_resources') || '[]');
  const res = resources.find(r => r.id === id);
  if (!res) return;

  document.getElementById('edit-resource-id').value = res.id;
  document.getElementById('edit-resource-title').value = res.title;
  document.getElementById('edit-resource-url').value = res.url;
  document.getElementById('edit-resource-desc').value = res.desc;

  document.getElementById('edit-resource-modal').classList.add('active');
};

document.getElementById('close-resource-modal-btn').addEventListener('click', () => {
  document.getElementById('edit-resource-modal').classList.remove('active');
});

document.getElementById('edit-resource-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const id = parseInt(document.getElementById('edit-resource-id').value);
  const resources = JSON.parse(localStorage.getItem('evangelism_resources') || '[]');
  const index = resources.findIndex(r => r.id === id);

  if (index !== -1) {
    resources[index].title = document.getElementById('edit-resource-title').value;
    resources[index].url = document.getElementById('edit-resource-url').value;
    resources[index].desc = document.getElementById('edit-resource-desc').value;

    localStorage.setItem('evangelism_resources', JSON.stringify(resources));
    document.getElementById('edit-resource-modal').classList.remove('active');
    renderResources();
  }
});

window.deleteResource = function(id) {
  if (confirm('Delete this resource?')) {
    let resources = JSON.parse(localStorage.getItem('evangelism_resources') || '[]');
    resources = resources.filter(r => r.id !== id);
    localStorage.setItem('evangelism_resources', JSON.stringify(resources));
    renderResources();
  }
};

// --- TEAM MANAGEMENT (DIRECTOR & ADMIN LEVEL) ---
document.getElementById('add-member-form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const targetGroup = getEffectiveGroupName();
  const newMemberName = document.getElementById('member-name').value;
  const newMemberEmail = document.getElementById('member-email').value;
  const newMemberRole = document.getElementById('member-role').value;
  const newMemberId = 'user_' + Date.now();

  const newMember = {
    id: newMemberId,
    name: newMemberName,
    email: newMemberEmail,
    role: newMemberRole,
    groupName: targetGroup
  };

  // Try to save to Supabase first
  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;
  if (supabase) {
    try {
      let { data: groupRows, error: groupLookupError } = await supabase
        .from('groups')
        .select('id')
        .eq('name', targetGroup)
        .limit(1);

      let groupId = groupRows && groupRows.length ? groupRows[0].id : null;

      if (!groupId) {
        const { data: insertedGroup, error: insertGroupError } = await supabase
          .from('groups')
          .insert([{ id: String(Date.now()), name: targetGroup }])
          .select('id');

        if (insertGroupError) {
          console.warn('Supabase group create failed:', insertGroupError.message);
        } else if (insertedGroup && insertedGroup[0]) {
          groupId = insertedGroup[0].id;
        }
      }

      const { error: insertError } = await supabase
        .from('users')
        .insert([{
          id: newMemberId,
          full_name: newMemberName,
          email: newMemberEmail,
          role: newMemberRole,
          group_id: groupId
        }]);

      if (insertError) {
        console.warn('Supabase insert failed:', insertError.message);
      } else {
        console.log('User saved to Supabase:', newMemberId);
      }
    } catch (err) {
      console.warn('Supabase error:', err.message);
    }
  }

  // Always save to localStorage as backup
  const team = JSON.parse(localStorage.getItem('evangelism_team') || '[]');
  team.push(newMember);
  localStorage.setItem('evangelism_team', JSON.stringify(team));

  document.getElementById('add-member-form').reset();
  await renderTeam();
  renderEvangelistCheckboxes();
});

function canManageUser(targetUser) {
  if (!currentUser || !targetUser) return false;

  if (currentUser.role === 'super_admin') return true;

  const currentGroup = currentUser.groupName || activeGroupName;
  if (!currentGroup) return false;

  if (currentUser.role === 'director') {
    return targetUser.groupName === currentGroup && ['member', 'admin'].includes(targetUser.role);
  }

  if (currentUser.role === 'admin') {
    return targetUser.groupName === currentGroup && targetUser.role === 'member';
  }

  return false;
}

async function renderTeam() {
  if (!ensureUserSession()) return;

  const team = await loadTeamDataFromSupabase();
  const teamList = document.getElementById('team-list');
  teamList.innerHTML = '';

  const targetGroup = getEffectiveGroupName();
  const groupMembers = team.filter(m => currentUser.role === 'super_admin'
    ? m.groupName === targetGroup
    : m.groupName === currentUser.groupName);

  groupMembers.forEach(m => {
    const canEdit = canManageUser(m);
    const li = document.createElement('li');
    li.className = 'log-item';
    li.innerHTML = `
      <div class="log-item-header">
        <span class="log-item-title">${escapeHtml(m.name)}</span>
        <span class="badge">${escapeHtml(m.role)}</span>
      </div>
      <p class="log-item-notes">${escapeHtml(m.email)} | Group: ${escapeHtml(m.groupName)}</p>

      ${canEdit ? `
        <div class="log-actions">
          <button class="btn-action edit" onclick="openEditUserModal('${m.id}')">Edit Member</button>
          <button class="btn-action delete" onclick="deleteUser('${m.id}')">Remove Member</button>
        </div>
      ` : ''}
    `;
    teamList.appendChild(li);
  });
}

// --- SUPER ADMIN PANEL (MANAGE DIRECTORS & ALL GROUPS) ---
document.getElementById('appoint-director-form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const groupName = document.getElementById('group-name').value.trim();
  const directorName = document.getElementById('director-name').value.trim();
  const directorEmail = document.getElementById('director-email').value.trim();

  if (!groupName || !directorName || !directorEmail) {
    alert('Please complete the group name, director name, and director email.');
    return;
  }

  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;
  const groupId = slugifyGroupName(groupName);
  const directorId = 'dir_' + Date.now();
  const newDirector = {
    id: directorId,
    name: directorName,
    email: directorEmail,
    role: 'director',
    groupName: groupName
  };

  try {
    if (supabase) {
      const { data: existingGroup, error: existingGroupError } = await supabase
        .from('groups')
        .select('id')
        .eq('name', groupName)
        .limit(1);

      let resolvedGroupId = groupId;

      if (existingGroupError) {
        console.warn('Group lookup failed:', existingGroupError.message);
      } else if (existingGroup && existingGroup.length) {
        resolvedGroupId = existingGroup[0].id;
      } else {
        const { data: insertedGroup, error: insertGroupError } = await supabase
          .from('groups')
          .upsert([{ id: resolvedGroupId, name: groupName }], { onConflict: 'id' })
          .select('id');

        if (insertGroupError) {
          console.warn('Supabase group insert failed:', insertGroupError.message);
        } else if (insertedGroup && insertedGroup.length) {
          resolvedGroupId = insertedGroup[0].id;
        }
      }

      const { error: insertUserError } = await supabase
        .from('users')
        .insert([{ id: directorId, full_name: directorName, email: directorEmail, role: 'director', group_id: resolvedGroupId }]);

      if (insertUserError) {
        console.warn('Supabase director insert failed:', insertUserError.message);
      }

      const cachedGroupIds = JSON.parse(localStorage.getItem('evangelism_group_ids') || '{}');
      cachedGroupIds[groupName] = resolvedGroupId;
      localStorage.setItem('evangelism_group_ids', JSON.stringify(cachedGroupIds));

      const defaultResources = DEFAULT_RESOURCES.map((def, index) => ({
        id: `group_resource_${Date.now()}_${index}`,
        group_id: resolvedGroupId,
        title: def.title,
        url: def.url,
        description: def.desc
      }));

      const { error: resourceInsertError } = await supabase
        .from('resources')
        .upsert(defaultResources, { onConflict: 'id' });

      if (resourceInsertError) {
        console.warn('Supabase default resource insert failed:', resourceInsertError.message);
      }
    }

    const team = getStoredArray('evangelism_team');
    team.push(newDirector);
    localStorage.setItem('evangelism_team', JSON.stringify(team));
    activeGroupName = groupName;

    const resources = getStoredArray('evangelism_resources');
    DEFAULT_RESOURCES.forEach(def => {
      resources.push({
        id: Date.now() + Math.floor(Math.random() * 1000),
        groupName: groupName,
        title: def.title,
        url: def.url,
        desc: def.desc
      });
    });
    localStorage.setItem('evangelism_resources', JSON.stringify(resources));

    document.getElementById('appoint-director-form').reset();
    await renderSuperAdminPanel();
    await renderTeam();
    await renderResources();
  } catch (error) {
    console.warn('Director creation failed:', error);
    alert('Unable to save the director and group right now. Please try again.');
  }
});

async function renderSuperAdminPanel() {
  if (!ensureUserSession()) return;

  const team = await loadTeamDataFromSupabase();
  const directorList = document.getElementById('director-list');
  directorList.innerHTML = '';

  const directors = team.filter(m => m.role === 'director');

  if (directors.length === 0) {
    directorList.innerHTML = '<li class="empty-state">No directors assigned yet.</li>';
    return;
  }

  directors.forEach(d => {
    const li = document.createElement('li');
    li.className = 'log-item';
    li.style.cursor = 'pointer';
    li.title = `Open ${d.groupName} as director view`;
    const isActive = currentUser.role === 'super_admin' && activeGroupName === d.groupName;
    li.innerHTML = `
      <div class="log-item-header">
        <span class="log-item-title">${escapeHtml(d.name)} (Director)</span>
        <span class="badge group-tag">${escapeHtml(d.groupName)}</span>
      </div>
      <p class="log-item-notes">${escapeHtml(d.email)}</p>
      <div class="log-actions">
        <button class="btn-action edit" onclick="setActiveGroupContext('${d.groupName}')">${isActive ? 'Active Group' : 'Open as Director'}</button>
        <button class="btn-action edit" onclick="openEditUserModal('${d.id}')">Edit Director/Group</button>
        <button class="btn-action delete" onclick="deleteUser('${d.id}')">Remove Director</button>
      </div>
    `;

    li.addEventListener('click', (event) => {
      if (event.target.closest('button')) return;
      setActiveGroupContext(d.groupName);
    });

    directorList.appendChild(li);
  });
}

// --- USER EDIT & DELETE MODAL (SUPER ADMIN & DIRECTORS) ---
window.openEditUserModal = async function(userId) {
  const team = await loadTeamDataFromSupabase();
  const u = team.find(m => m.id === userId);
  if (!u) return;

  if (!canManageUser(u)) {
    alert('You do not have permission to edit this account.');
    return;
  }

  document.getElementById('edit-user-id').value = u.id;
  document.getElementById('edit-user-name').value = u.name;
  document.getElementById('edit-user-email').value = u.email;
  document.getElementById('edit-user-role').value = u.role;
  document.getElementById('edit-user-group').value = u.groupName || '';

  document.getElementById('edit-user-modal').classList.add('active');
};

document.getElementById('close-user-modal-btn').addEventListener('click', () => {
  document.getElementById('edit-user-modal').classList.remove('active');
});

document.getElementById('edit-user-form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const uId = document.getElementById('edit-user-id').value;
  const updatedName = document.getElementById('edit-user-name').value.trim();
  const updatedEmail = document.getElementById('edit-user-email').value.trim();
  const updatedRole = document.getElementById('edit-user-role').value;
  const updatedGroupName = document.getElementById('edit-user-group').value.trim();

  if (!uId || !updatedName || !updatedEmail) {
    alert('Please complete the user name and email.');
    return;
  }

  const team = await loadTeamDataFromSupabase();
  const targetUser = team.find(m => m.id === uId);
  if (!targetUser || !canManageUser(targetUser)) {
    alert('You do not have permission to edit this account.');
    return;
  }

  if (currentUser.role === 'director' && !['member', 'admin'].includes(updatedRole)) {
    alert('A director can only manage members and admins in their group.');
    return;
  }

  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;

  try {
    let groupId = null;
    if (supabase && updatedGroupName) {
      let { data: groupRows } = await supabase
        .from('groups')
        .select('id')
        .eq('name', updatedGroupName)
        .limit(1);

      if (!groupRows || !groupRows.length) {
        const { data: insertedGroup, error: insertGroupError } = await supabase
          .from('groups')
          .upsert([{ id: slugifyGroupName(updatedGroupName), name: updatedGroupName }], { onConflict: 'id' })
          .select('id');

        if (insertGroupError) {
          console.warn('Group update failed:', insertGroupError.message);
        } else if (insertedGroup && insertedGroup.length) {
          groupId = insertedGroup[0].id;
        }
      } else {
        groupId = groupRows[0].id;
      }
    }

    const updatedUserPayload = {
      full_name: updatedName,
      email: updatedEmail,
      role: updatedRole,
      group_id: groupId
    };

    if (supabase) {
      const { error: updateError } = await supabase
        .from('users')
        .update(updatedUserPayload)
        .eq('id', uId);

      if (updateError) {
        console.warn('Supabase user update failed:', updateError.message);
      }
    }

    const localTeam = getStoredArray('evangelism_team');
    const index = localTeam.findIndex(m => m.id === uId);
    if (index !== -1) {
      localTeam[index].name = updatedName;
      localTeam[index].email = updatedEmail;
      localTeam[index].role = updatedRole;
      localTeam[index].groupName = updatedGroupName;
      localStorage.setItem('evangelism_team', JSON.stringify(localTeam));
    }

    document.getElementById('edit-user-modal').classList.remove('active');
    await renderTeam();
    if (currentUser && currentUser.role === 'super_admin') await renderSuperAdminPanel();
  } catch (error) {
    console.warn('User edit failed:', error);
    alert('Unable to update this user right now.');
  }
});

window.deleteUser = async function(userId) {
  if (!confirm('Delete this user account?')) return;

  const team = await loadTeamDataFromSupabase();
  const targetUser = team.find(m => m.id === userId);
  if (!targetUser || !canManageUser(targetUser)) {
    alert('You do not have permission to delete this account.');
    return;
  }

  const supabase = window.getSupabaseClient ? window.getSupabaseClient() : null;

  try {
    if (supabase) {
      const { error: deleteError } = await supabase
        .from('users')
        .delete()
        .eq('id', userId);

      if (deleteError) {
        console.warn('Supabase user delete failed:', deleteError.message);
      }
    }

    let localTeam = getStoredArray('evangelism_team');
    localTeam = localTeam.filter(m => m.id !== userId);
    localStorage.setItem('evangelism_team', JSON.stringify(localTeam));

    await renderTeam();
    if (currentUser && currentUser.role === 'super_admin') await renderSuperAdminPanel();
  } catch (error) {
    console.warn('User deletion failed:', error);
    alert('Unable to delete this user right now.');
  }
};
